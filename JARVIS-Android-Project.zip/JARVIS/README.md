# JARVIS — Android voice assistant starter

A native Kotlin + Jetpack Compose Android app with:
- Voice input using Android SpeechRecognizer
- Spoken replies using Android TextToSpeech
- Typed commands
- Local commands for time and date
- Open YouTube, Google Search, and Maps
- A dark JARVIS-style interface

## Build an APK without installing Termux

### Easiest cloud build (GitHub Actions)
1. On GitHub, create a new **public or private repository** named `JARVIS`.
2. Upload the *contents* of this folder to the repository (the `.github/workflows/build-apk.yml` file must be included).
3. Open the repository's **Actions** tab and select **Build JARVIS APK**.
4. If asked, enable Actions. Press **Run workflow**.
5. Wait for the workflow to finish successfully.
6. Open the completed run and download the `JARVIS-debug-APK` artifact.
7. Extract the downloaded ZIP on your phone and tap `app-debug.apk` to install. Android may ask you to allow installs from that browser/file manager; only allow it for the app you used to download/open the file, then turn it off again afterward.

The workflow uses a cloud runner to compile the APK; no Android SDK or Termux is needed on your phone.

### Build locally
- Android Studio
- JDK 17
- Android SDK platform 35

Open this folder in Android Studio, sync Gradle, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

## Current limitations
This is a functional starter, not yet a full online Gemini-powered JARVIS. It does not contain an API key, and it does not send your voice or messages to an online AI service. A secure Gemini connection requires a backend or a deliberate key-management setup; do not put a private production API key directly into a distributable APK.

Speech recognition depends on the speech service and languages installed on the phone. The app asks for microphone permission when you first tap the microphone.
