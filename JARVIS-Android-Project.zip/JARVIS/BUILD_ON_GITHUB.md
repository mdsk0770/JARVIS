# Build the JARVIS APK using GitHub Actions

This project has a GitHub Actions workflow at `.github/workflows/build-apk.yml`.

1. Create a repository named `JARVIS` at https://github.com/new.
2. Upload the **contents** of this project folder to the repository root. Ensure `.github/workflows/build-apk.yml` is present at that exact path (not nested under another `JARVIS` folder).
3. Open the repository's **Actions** tab and choose **Build JARVIS APK**.
4. Choose **Run workflow** if it has not started automatically after the first push.
5. Wait for a green successful run. Open that run and download the `JARVIS-debug-APK` artifact.
6. Extract the artifact ZIP on your Android phone and install `app-debug.apk`.

If the workflow fails, open the failed run and share the first red error section; do not share API keys or passwords.

## What this APK does
- Voice input via Android SpeechRecognizer (requires microphone permission and a compatible speech service)
- Spoken replies via Android TextToSpeech
- Typed commands
- Local time/date answers
- Opens YouTube, Google, and Maps via Android intents

## Important
This is a starter assistant, not a full Gemini-connected assistant. It does not include a Gemini API key or send messages to Gemini. Never put a private production API key in a public repository or directly into a distributed APK.
