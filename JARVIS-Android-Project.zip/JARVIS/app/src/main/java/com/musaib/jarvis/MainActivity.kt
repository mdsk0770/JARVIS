package com.musaib.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF07111F)
private val Panel = Color(0xFF101F31)
private val Cyan = Color(0xFF5CE1E6)
private val White = Color(0xFFEAF4FF)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var ttsReady = false
    private var onRecognized: ((String) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        setContent { JarvisScreen(onListen = { callback -> listen(callback) }, onSpeak = { speak(it) }, onCommand = { runCommand(it) }) }
    }

    override fun onInit(status: Int) { ttsReady = status == TextToSpeech.SUCCESS; if (ttsReady) tts?.language = Locale.getDefault() }
    private fun speak(text: String) { if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply") }

    private fun listen(callback: (String) -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            callback("MIC_PERMISSION_REQUIRED"); return
        }
        val sr = recognizer
        if (sr == null) { callback("Speech recognition is not available on this device."); return }
        onRecognized = callback
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { onRecognized?.invoke("I couldn't hear that clearly. Please try again.") }
            override fun onResults(results: Bundle?) { val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty(); onRecognized?.invoke(phrase.ifBlank { "I didn't catch that." }) }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        sr.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
        })
    }

    private fun runCommand(raw: String): String {
        val q = raw.lowercase(Locale.getDefault())
        val answer = when {
            q.contains("time") -> "The time is ${SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())}."
            q.contains("date") || q.contains("today") -> "Today is ${SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())}."
            q.contains("open youtube") -> { openUrl("https://www.youtube.com"); "Opening YouTube." }
            q.contains("open google") || q.contains("search google") -> { openUrl("https://www.google.com"); "Opening Google." }
            q.contains("open maps") -> { openUrl("https://maps.google.com"); "Opening Maps." }
            q.contains("hello") || q.contains("hi jarvis") || q == "hi" -> "Hello! JARVIS is online. How can I help?"
            q.contains("your name") -> "I am JARVIS, your personal voice assistant."
            q.contains("help") -> "Try saying: what time is it, today's date, open YouTube, open Google, or open Maps."
            else -> "I heard: $raw. This starter version supports basic offline commands. Gemini AI chat can be connected in the next build."
        }
        speak(answer)
        return answer
    }
    private fun openUrl(url: String) { runCatching { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))) } }
    override fun onDestroy() { recognizer?.destroy(); tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

@Composable
private fun JarvisScreen(onListen: ((String) -> Unit) -> Unit, onSpeak: (String) -> Unit, onCommand: (String) -> String) {
    var input by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("SYSTEM READY") }
    var messages by remember { mutableStateOf(listOf("JARVIS: Online. Tap the microphone or type a command.")) }
    var permissionRequest by remember { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { listening = true; status = "LISTENING…"; onListen { heard -> listening = false; status = "SYSTEM READY"; if (heard == "MIC_PERMISSION_REQUIRED") return@onListen; messages = messages + "YOU: $heard" + "JARVIS: ${onCommand(heard)}" } }
        else { status = "MIC PERMISSION DENIED" }
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Panel, onSurface = White)) {
        Column(Modifier.fillMaxSize().background(Bg).padding(20.dp)) {
            Text("J.A.R.V.I.S", color = Cyan, fontSize = 28.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
            Text("PERSONAL VOICE ASSISTANT", color = White.copy(alpha = .65f), fontSize = 11.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(22.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(118.dp).background(Cyan.copy(alpha = .09f), CircleShape), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(86.dp).background(Cyan.copy(alpha = .15f), CircleShape), contentAlignment = Alignment.Center) { Text(if (listening) "•••" else "J", color = Cyan, fontSize = 38.sp, fontWeight = FontWeight.Light) }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(status, color = Cyan, fontSize = 12.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(14.dp))
                    Button(onClick = {
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            listening = true; status = "LISTENING…"; onListen { heard -> listening = false; status = "SYSTEM READY"; if (heard != "MIC_PERMISSION_REQUIRED") messages = messages + "YOU: $heard" + "JARVIS: ${onCommand(heard)}" }
                        } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }, colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg), modifier = Modifier.fillMaxWidth()) { Text(if (listening) "LISTENING…" else "🎙  TAP TO SPEAK", fontWeight = FontWeight.Bold) }
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("CONVERSATION", color = Cyan, fontSize = 12.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(8.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.weight(1f).fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { items(messages) { line -> Text(line, color = if (line.startsWith("JARVIS:")) Cyan else White, fontSize = 14.sp) } }
            }
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Type a command…", color = White.copy(alpha = .5f)) }, singleLine = true, shape = RoundedCornerShape(14.dp))
                Spacer(Modifier.width(8.dp))
                Button(onClick = { val q = input.trim(); if (q.isNotEmpty()) { messages = messages + "YOU: $q" + "JARVIS: ${onCommand(q)}"; input = "" } }, colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg)) { Text("SEND") }
            }
            Spacer(Modifier.height(8.dp))
            Text("Basic commands: time • date • open YouTube • open Google • open Maps", color = White.copy(alpha = .5f), fontSize = 10.sp)
        }
    }
}
